
package com.example.restauranteapp.model;

public class Plato {
    private String nombre;
    private String precio;

    public Plato(String nombre, String precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrecio() {
        return precio;
    }
}
